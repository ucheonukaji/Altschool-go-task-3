# **ATM** CLI application

**Default password**: 4194

## App features
- Change Pin (you can create a default pin in your code and then change it in the function)
- Account balance
- Withdraw funds
- Deposit funds
- Cancel/Exit (selecting this option should exit the program)

## Usage
```bash
go run .
```
https://www.sendspace.com/file/1tss7w

